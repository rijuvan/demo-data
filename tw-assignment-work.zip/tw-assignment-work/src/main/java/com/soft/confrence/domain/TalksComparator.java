/**
 * 
 */
package com.soft.confrence.domain;

import java.util.Comparator;

/**
 * @author Rijuvan.Ansari
 *
 */
public class TalksComparator  implements Comparator<Talk> {

	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int compare(Talk o1, Talk o2) {
		// TODO Auto-generated method stub
		if(o1.getDurationInMinutes() < o2.getDurationInMinutes()){
            return 1;
        } else {
            return -1;
        }
	}

}

/**
 * 
 */
package com.soft.confrence.domain.ops;

import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.soft.confrence.domain.Conference;
import com.soft.confrence.domain.Event;
import com.soft.confrence.domain.Lunch;
import com.soft.confrence.domain.Networking;
import com.soft.confrence.domain.Slot;
import com.soft.confrence.domain.Talk;
import com.soft.confrence.domain.TalksComparator;
import com.soft.confrence.domain.Track;
import com.soft.confrence.domain.config.ConferenceAppConfig;
import com.soft.confrence.domain.utils.ConferenceDateTimeUtils;

/**
 * @author Rijuvan.Ansari
 *
 */
public class ConferenceTalkScheduler {

	public Conference processAndScheduleTalks(List<Talk> talkList) {
		Conference conference = new Conference();

		// sort all the talks in descending order
	//	talkList.sort((Talk t1, Talk t2)-> (t1.getDurationInMinutes() - t2.getDurationInMinutes()));
		Collections.sort(talkList, new TalksComparator());
		int trackCount = 0;

		// run this loop till all the talks are scheduled.
		while (0 != talkList.size()) {

			// create and fill morning slot.
Slot morningSlot = new Slot(ConferenceAppConfig.MORNING_SLOT_DURATION_MINUTES,
					ConferenceAppConfig.TRACK_START_TIME);
			fillSlot(morningSlot, talkList);

			// create and fill lunch slot.
			Slot lunchSlot = new Slot(ConferenceAppConfig.LUNCH_DURATION_MINUTES,
					ConferenceAppConfig.LUNCH_START_TIME);
			lunchSlot.addEvent(new Lunch());

			// create and fill afternoon slot.
			Slot afternoonSlot = new Slot(ConferenceAppConfig.AFTERNOON_SLOT_DURATION_MINUTES,
					ConferenceAppConfig.POST_LUNCH_SLOT_START_TIME);
			fillSlot(afternoonSlot, talkList);

			// create and fill networking slot.
			Slot networkingSlot = new Slot(ConferenceAppConfig.NETWORKING_DURATION_MINUTES,
					ConferenceAppConfig.NETWORKING_START_TIME);
			networkingSlot.addEvent(new Networking());

			// add all the slots for the day into the track.
			Track track = new Track(++trackCount);
			track.addSlot(morningSlot);
			track.addSlot(lunchSlot);
			track.addSlot(afternoonSlot);
			track.addSlot(networkingSlot);
			// add track to the conference.
			conference.addTrack(track);
		}

		return conference;
	}
	
	private void fillSlot(Slot slot, List<Talk> talks) {
		// initialize the slot start time.
		Calendar currentStartTime = slot.getStartTime();
		for (Iterator<Talk> talksIterator = talks.iterator(); talksIterator.hasNext();) {
			Talk talk = talksIterator.next();
			if (slot.hasRoomFor(talk)) {
				// add an event to the slot at the currentStartTime calculated.
				slot.addEvent(new Event(currentStartTime, talk.getTitle(), talk.getDurationInMinutes()));
				// calculate the next start time based on the current start time
				// and current talk duration.
				currentStartTime = ConferenceDateTimeUtils.getNextStartTime(currentStartTime, talk);
				// remove the talk from the list. This means that the talk has
				// been scheduled in the conference.
				talksIterator.remove();
			}
		}
	}


}

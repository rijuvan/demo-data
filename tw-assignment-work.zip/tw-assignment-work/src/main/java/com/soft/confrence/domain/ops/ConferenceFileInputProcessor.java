/**
 * 
 */
package com.soft.confrence.domain.ops;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.soft.confrence.domain.Talk;
import com.soft.confrence.domain.config.ConferenceAppConfig;
import com.soft.confrence.domain.utils.ConferenceDateTimeUtils;
import com.soft.confrence.domain.utils.ConfrenceFileUtil;

/**
 * @author Rijuvan.Ansari
 *
 */
public class ConferenceFileInputProcessor implements ConferenceInput {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.soft.confrence.domain.ops.ConferenceInput#fetchTalksListFromFile()
	 */
	@Override
	public List<Talk> fetchTalksListFromFile(String fileName) {
		ArrayList<Talk> talkList = new ArrayList<Talk>();
		// read file into stream, try-with-resources
		try (Stream<String> stream = Files.lines(Paths.get(fileName))) {

			List<String> list = stream.collect(Collectors.toList());

			ArrayList<String> arrList = new ArrayList<String>(list);

			for (String listVal : arrList) {

				String talkTitle = listVal.substring(0, listVal.lastIndexOf(" "));
				// System.out.println(talkTitle);

				String talkDuration = listVal.substring(listVal.lastIndexOf(" ") + 1);
				Talk talk = null;
				// System.out.println(talkDuration.substring(0,2));
				if (talkDuration.equals("lightning")) {
					talk = new Talk(talkDuration, 5);
					talkList.add(talk);
				} else {
					talk = new Talk(talkTitle, Integer.parseInt(talkDuration.substring(0, 2)));
					talkList.add(talk);
				}

			}
			return talkList;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return talkList;
	}

}

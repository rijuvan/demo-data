/**
 * 
 */
package com.soft.confrence.domain;

import java.util.Calendar;



/**
 * @author Rijuvan.Ansari
 *
 */
public class Event {
	 private Calendar startTime;
	    private int durationInMinutes;
	    private String title;

	    public Event(Calendar startTime, String title, int durationInMinutes){
	        this.startTime = startTime;
	        this.title = title;
	        this.durationInMinutes = durationInMinutes;
	    }

	    public Calendar getStartTime() {
	        return startTime;
	    }

	    /* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		

		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		

		public int getDurationInMinutes() {
	        return durationInMinutes;
	    }

	    public String getTitle() {
	        return title;
	    }

	}


/**
 * 
 */
package com.soft.confrence.domain.ops;

import java.util.List;

import com.soft.confrence.domain.Talk;

/**
 * @author Rijuvan.Ansari
 *
 */
public interface ConferenceInput {
	public List<Talk> fetchTalksListFromFile(String fileName) ;
	
	default	public  List<Talk> fetchTalksListFromDb(String usernme,String password,String dbUrl) 
	{
		return null;
	}
}

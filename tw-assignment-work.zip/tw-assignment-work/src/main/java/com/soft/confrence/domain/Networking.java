/**
 * 
 */
package com.soft.confrence.domain;

import com.soft.confrence.domain.config.ConferenceAppConfig;

/**
 * @author Rijuvan.Ansari
 *
 */
public class Networking  extends Event{

	public Networking () {
        super(ConferenceAppConfig.NETWORKING_START_TIME, "Networking Event", 0);
    }
}

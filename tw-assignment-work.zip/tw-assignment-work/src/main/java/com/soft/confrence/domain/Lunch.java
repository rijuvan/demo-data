/**
 * 
 */
package com.soft.confrence.domain;

import com.soft.confrence.domain.config.ConferenceAppConfig;

/**
 * @author Rijuvan.Ansari
 *
 */
public class Lunch  extends Event{

	public Lunch() {
        super(ConferenceAppConfig.LUNCH_START_TIME, "Lunch", ConferenceAppConfig.LUNCH_DURATION_MINUTES);
    }
}

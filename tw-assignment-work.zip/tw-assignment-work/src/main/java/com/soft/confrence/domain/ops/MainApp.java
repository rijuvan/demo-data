/**
 * 
 */
package com.soft.confrence.domain.ops;

import java.util.List;

import com.soft.confrence.domain.Conference;
import com.soft.confrence.domain.Talk;
import com.soft.confrence.domain.utils.ConferenceDateTimeUtils;
import com.soft.confrence.domain.utils.ConfrenceFileUtil;

/**
 * @author Rijuvan.Ansari
 *
 */
public class MainApp {

	public static void main(String args[]) {
		ConferenceFileInputProcessor confrenceInput = new ConferenceFileInputProcessor();
		ConferenceTalkScheduler conftalkSchedule = new ConferenceTalkScheduler();
		List<Talk> talkList = null;
		// Fetch the input talk list.

		talkList = confrenceInput.fetchTalksListFromFile(ConfrenceFileUtil.getConfiValue("TALKS_INPUT_FILE"));

		if (talkList == null || talkList.size() == 0)
			return;

		// Process and schedule talks into events and slots.
		Conference conference = conftalkSchedule.processAndScheduleTalks(talkList);

		new ConferenceSchedulePublisher().printSchedule(conference);

	}
}

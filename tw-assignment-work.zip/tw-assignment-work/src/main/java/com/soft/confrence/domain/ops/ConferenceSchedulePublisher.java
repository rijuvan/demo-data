/**
 * 
 */
package com.soft.confrence.domain.ops;

import java.text.SimpleDateFormat;
import java.util.List;

import com.soft.confrence.domain.Conference;
import com.soft.confrence.domain.Slot;
import com.soft.confrence.domain.config.ConferenceAppConfig;
import com.soft.confrence.domain.Track;
import com.soft.confrence.domain.Event;

/**
 * @author Rijuvan.Ansari
 *
 */

public class ConferenceSchedulePublisher {

	public void printSchedule(Conference conference) {

		SimpleDateFormat sdf = ConferenceAppConfig.DATE_FORMAT;
		System.out.println("Output: Conference Schedule :");
		// print the Conference schedule
		for (Track track : conference.getTracks()) {
			System.out.println("Track " + track.getTrackId());
			List<Slot> slots = track.getSlots();
			System.out.println("");

			// Output the talks into tracks based on the totalTalks and the
			// count of Talks.

			for (Slot slot : slots) {

				for (Event event : slot.getEvents()) {

					// Print the prepared talk's title for this Track
					System.out.println(sdf.format(event.getStartTime().getTime()) + " " + event.getTitle() + " "
							+ event.getDurationInMinutes() + "min");
				}
			}

		}
	}

}

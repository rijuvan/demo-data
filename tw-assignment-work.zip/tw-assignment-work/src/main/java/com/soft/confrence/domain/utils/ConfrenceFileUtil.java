/**
 * 
 */
package com.soft.confrence.domain.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author Rijuvan.Ansari
 *
 */
public class ConfrenceFileUtil {
	public static String getConfiValue(String propertyName) {

		try (InputStream input = new FileInputStream("conference.properties")) {

			Properties prop = new Properties();

			prop.load(input);
			return (prop.getProperty(propertyName));

		} catch (IOException io) {
			io.printStackTrace();
		}
		return null;
	}

}

/**
 * 
 */
package com.soft.conference.test;

import org.junit.Test;

import com.soft.confrence.domain.Talk;
import com.soft.confrence.domain.config.ConferenceAppConfig;
import com.soft.confrence.domain.ops.ConferenceFileInputProcessor;

import java.util.List;

import org.junit.*;

/**
 * @author Rijuvan.Ansari
 *
 */
public class FileInputProcesroTest {

	String fileName = null;
	String emptyFileName = null;

	
	
	@Before
	public void init() {
		fileName = "conference-success.txt";
		emptyFileName="emptyFile.txt";
	}

	@Test
	public void testConfigAppTest() {
		Assert.assertEquals(420, ConferenceAppConfig.TOTAL_TRACK_DURATION_MINUTES);

	}

	@Test
	public void testConfrenceFileInputProceesor() {
		ConferenceFileInputProcessor proc1 = new ConferenceFileInputProcessor();
		List<Talk> myList2 = proc1.fetchTalksListFromFile(fileName);
		Assert.assertEquals(7, myList2.size());

	}
	
	@Test
	public void testConfrenceEmptyFileInputProceesor() {
		ConferenceFileInputProcessor proc1 = new ConferenceFileInputProcessor();
		List<Talk> myList2 = proc1.fetchTalksListFromFile(emptyFileName);
		Assert.assertEquals(0, myList2.size());

	}

	
	@Test
	public void testConfrenceNoFileInputProceesor() {
		ConferenceFileInputProcessor proc1 = new ConferenceFileInputProcessor();
		List<Talk> myList2 = proc1.fetchTalksListFromFile("filedoesnotexists");
		Assert.assertEquals(0, myList2.size());

	}

}

/**
 * 
 */
package com.soft.conference.test;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.soft.confrence.domain.Conference;
import com.soft.confrence.domain.Talk;
import com.soft.confrence.domain.ops.ConferenceSchedulePublisher;
import com.soft.confrence.domain.ops.ConferenceTalkScheduler;
import static org.mockito.Mockito.when;

/**
 * @author Rijuvan.Ansari
 *
 */
public class ConferenceTalkSchedulerTest {
	Conference conference = null;

	ConferenceTalkScheduler ctalkscheduler = null;
	ArrayList<Talk> talkList = null;

	@Before
	public void init() {
		conference = new Conference();
		talkList = new ArrayList<Talk>();
		ctalkscheduler = mock(ConferenceTalkScheduler.class);

		when(ctalkscheduler.processAndScheduleTalks(talkList)).thenReturn(conference);
		// doNothing().when(ctaskscheduler).processAndScheduleTalks(talkList);
	}

	@Test
	public void testprocessAndScheduleTalks() {

		Assert.assertSame(conference,ctalkscheduler.processAndScheduleTalks(talkList));
	}

}

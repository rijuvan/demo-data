/**
 * 
 */
package com.soft.conference.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.soft.confrence.domain.utils.ConfrenceFileUtil;

/**
 * @author Rijuvan.Ansari
 *
 */
public class ConferenceUtilTest {

	ConfrenceFileUtil conf = null;

	@Before
	public void init() {

		conf = new ConfrenceFileUtil();

	}

	@Test
	public void testFileProp() {
		
		
		Assert.assertEquals("confrencedetail.txt",conf.getConfiValue("TALKS_INPUT_FILE"));

	}
	
	@Test
	public void testNullProp() {
		
		
		Assert.assertEquals(null,conf.getConfiValue("TALKS_INPUT_FILE-1"));

	}
}

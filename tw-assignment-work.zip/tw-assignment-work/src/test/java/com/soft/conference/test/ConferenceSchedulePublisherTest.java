/**
 * 
 */
package com.soft.conference.test;

import org.junit.Before;
import org.junit.Test;

import com.soft.confrence.domain.Conference;
import com.soft.confrence.domain.ops.ConferenceSchedulePublisher;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
/**
 * @author Rijuvan.Ansari
 *
 */
public class ConferenceSchedulePublisherTest {

	Conference conference = null;

	ConferenceSchedulePublisher cpubs = null;

	@Before
	public void init() {
		conference = new Conference();
		cpubs = mock(ConferenceSchedulePublisher.class);
		doNothing().when(cpubs).printSchedule(conference);
	}

	@Test
	public void testConFerenceSchedulePub()
	{
		cpubs.printSchedule(conference);
		verify(cpubs, times(1)).printSchedule(conference);
		
		
	}
}

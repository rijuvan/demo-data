/**
 * 
 */
package com.soft.conference.test;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.soft.confrence.domain.Talk;
import com.soft.confrence.domain.ops.ConferenceInput;

import org.junit.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.*;

/**
 * @author Rijuvan.Ansari
 *
 */
public class ConferenceInputTest {
private ConferenceInput confrenceInput;
	
	private Talk t1;
	private Talk t2;
	private Talk t3;
	private ArrayList<Talk> talkList;
	String fileName="test.txt";
	@Before
	public void setUp()
	{
		confrenceInput=mock(ConferenceInput.class);
		talkList=new ArrayList<Talk>();
		talkList.add(t1);
		talkList.add(t2);
		talkList.add(t3);
		
		when(confrenceInput.fetchTalksListFromFile("test.txt")).thenReturn(talkList);
		
	}
	
	@Test
	public void testConfrenceInput()
	{
	
		
		Assert.assertEquals(3, confrenceInput.fetchTalksListFromFile("test.txt").size());
		
	}
	
}
